"""
Heavily inspiredfrom Jack Ma "high Frequency", although a lot of things have to go...

"""
import pandas as pd
from ib.opt import ibConnection, message as ib_message_type
from ib.opt import Connection
import datetime as dt
import time
from classes.ib_util import IBUtil
from classes.stock_data import StockData
import params.ib_data_types as datatype
#from params.strategy_parameters import StrategyParameters
#from classes.chart import Chart
import threading
import sys
import os

#this will need be checked



class HFTModel:

    def __init__(self, host='localhost', port=4001,
                 client_id=125, is_use_gateway=False, evaluation_time_secs=20,
                 resample_interval_secs='30s',
                 moving_window_period=dt.timedelta(seconds=5)):
        self.moving_window_period = moving_window_period
#        self.chart = Chart()
        self.ib_util = IBUtil()

        # Store parameters for this model
#        self.strategy_params = StrategyParameters(evaluation_time_secs,
#                                                  resample_interval_secs)

        self.stocks_data = {}  # Dictionary storing StockData objects.
        self.symbols = None  # List of current symbols
        self.account_code = ""
        self.prices = None  # Store last prices in a DataFrame
        self.trade_qty = 0
        self.order_id = 0
        self.lock = threading.Lock()
        #addition for hdf store
        self.data_path = os.path.normpath("/Users/maxime_back/Documents/avocado/data.csv")
#fuck hdfs witha cactus
#        self.store = pd.HDFStore(self.data_path)

        # Use ibConnection() for TWS, or create connection for API Gateway
        self.conn = ibConnection() if is_use_gateway else \
            Connection.create(host=host, port=port, clientId=client_id)
        self.__register_data_handlers(self.__on_tick_event,
                                      self.__event_handler)


    def __register_data_handlers(self,
                                 tick_event_handler,
                                 universal_event_handler):
        self.conn.registerAll(universal_event_handler)
        self.conn.unregister(universal_event_handler,
                             ib_message_type.tickSize,
                             ib_message_type.tickPrice,
                             ib_message_type.tickString,
                             ib_message_type.tickGeneric,
                             ib_message_type.tickOptionComputation)
        self.conn.register(tick_event_handler,
                           ib_message_type.tickPrice,
                           ib_message_type.tickSize)

    def __init_stocks_data(self, symbols):
        self.symbols = symbols
#here we'll store tick and size instead of multiple "symbols"
        self.prices = pd.DataFrame(columns=("price","size"))  # Init price storage
        if not os.path.exists(self.data_path):
            self.store = self.prices.to_csv(self.data_path)
#Now I have only one "symbol"        
        stock_symbol = self.symbols
        contract = self.ib_util.create_stock_contract(stock_symbol)
        self.stocks_data[stock_symbol] = StockData(contract)

    def __request_streaming_data(self, ib_conn):
        # Stream market data
        for index, (key, stock_data) in enumerate(
                self.stocks_data.iteritems()):
            ib_conn.reqMktData(index,
                               stock_data.contract,
                               datatype.GENERIC_TICKS_NONE,
                               datatype.SNAPSHOT_NONE)
            time.sleep(1)

        # Stream account updates
#        ib_conn.reqAccountUpdates(True, self.account_code)

#    def __request_historical_data(self, ib_conn):
#        self.lock.acquire()
#        try:
#            for index, (key, stock_data) in enumerate(
#                    self.stocks_data.iteritems()):
#                stock_data.is_storing_data = True
#                ib_conn.reqHistoricalData(
#                    index,
#                    stock_data.contract,
#                    time.strftime(datatype.DATE_TIME_FORMAT),
#                    datatype.DURATION_1_HR,
#                    datatype.BAR_SIZE_5_SEC,
#                    datatype.WHAT_TO_SHOW_TRADES,
#                    datatype.RTH_ALL,
#                    datatype.DATEFORMAT_STRING)
#                time.sleep(1)
#        finally:
#            self.lock.release()

#    def __wait_for_download_completion(self):
#        is_waiting = True
#        while is_waiting:
#            is_waiting = False
#
#            self.lock.acquire()
#            try:
#                for symbol in self.stocks_data.keys():
#                    if self.stocks_data[symbol].is_storing_data:
#                        is_waiting = True
#            finally:
#                self.lock.release()
#
#            if is_waiting:
#                time.sleep(1)


#    def __on_portfolio_update(self, msg):
#        for key, stock_data in self.stocks_data.iteritems():
#            if stock_data.contract.m_symbol == msg.contract.m_symbol:
#                stock_data.update_position(msg.position,
#                                           msg.marketPrice,
#                                           msg.marketValue,
#                                           msg.averageCost,
#                                           msg.unrealizedPNL,
#                                           msg.realizedPNL,
#                                           msg.accountName)
#                return
#
#    def __calculate_pnls(self):
#        upnl, rpnl = 0, 0
#        for key, stock_data in self.stocks_data.iteritems():
#            upnl += stock_data.unrealized_pnl
#            rpnl += stock_data.realized_pnl
#        return upnl, rpnl

    def __event_handler(self, msg):
        if msg.typeName == datatype.MSG_TYPE_HISTORICAL_DATA:
            pass
#            self.__on_historical_data(msg)
        

        elif msg.typeName == datatype.MSG_TYPE_UPDATE_PORTFOLIO:
            pass
#            self.__on_portfolio_update(msg)

        elif msg.typeName == datatype.MSG_TYPE_MANAGED_ACCOUNTS:
            pass

#            self.account_code = msg.accountsList

        elif msg.typeName == datatype.MSG_TYPE_NEXT_ORDER_ID:
            self.order_id = msg.orderId

        else:
            print msg

#    def __on_historical_data(self, msg):
#        print msg
#
#        ticker_index = msg.reqId
#
#        if msg.WAP == -1:
#            self.__on_historical_data_completed(ticker_index)
#        else:
#            self.__add_historical_data(ticker_index, msg)
#
#    def __on_historical_data_completed(self, ticker_index):
#        self.lock.acquire()
#        try:
#            symbol = self.symbols[ticker_index]
#            self.stocks_data[symbol].is_storing_data = False
#        finally:
#            self.lock.release()
#
#    def __add_historical_data(self, ticker_index, msg):
#        timestamp = dt.datetime.strptime(msg.date, datatype.DATE_TIME_FORMAT)
#        self.__add_market_data(ticker_index, timestamp, msg.close)

    def __on_tick_event(self, msg):
        ticker_id = msg.tickerId
        field_type = msg.field
#        print field_type

        # Store information from last traded price
        if field_type == datatype.FIELD_LAST_PRICE:
            last_price = msg.price
            self.__add_market_data(ticker_id, dt.datetime.now(), last_price, True)
        if field_type == datatype.FIELD_LAST_SIZE:
            last_size = msg.size
            self.__add_market_data(ticker_id, dt.datetime.now(), last_size, False)
            self.__trim_data_series()

        # Post-bootstrap - make trading decisions
#        if self.strategy_params.is_bootstrap_completed():
#            self.__recalculate_strategy_parameters_at_interval()
#            self.__perform_trade_logic()
#            self.__update_charts()

    def __add_market_data(self, ticker_index, timestamp, value, price):
        if price:
#prob can be removed safely            symbol = self.symbols[ticker_index]
            self.prices.loc[timestamp, "price"] = float(value)
#            self.prices = self.prices.fillna(method='ffill')  # Clear NaN values
            self.prices.sort_index(inplace=True)
        else:
#prob can be removed safely            symbol = self.symbols[ticker_index]
            self.prices.loc[timestamp, "size"] = float(value)
#            self.prices = self.prices.fillna(method='ffill')  # Clear NaN values
            self.prices.sort_index(inplace=True)


    def __trim_data_series(self):
        print "trim started"
        
        cutoff_timestamp = dt.datetime.now() - self.moving_window_period
#Fuck hdfs        
#        self.store.put("price",self.prices['price'].dropna(),format="table",append=True)
#        self.store.put("size",self.prices['size'].dropna(),format="table",append=True)
        with open(self.data_path, 'a') as f:
            self.prices[self.prices.index <= cutoff_timestamp].to_csv(f, header=False)
        

        self.prices = self.prices[self.prices.index >= cutoff_timestamp]
#        self.strategy_params.trim_indicators_series(cutoff_timestamp)

    @staticmethod
    def __print_elapsed_time(start_time):
        elapsed_time = time.time() - start_time
        print "Completed in %.3f seconds." % elapsed_time

    def __cancel_market_data_request(self):
        for i, symbol in enumerate(self.symbols):
            self.conn.cancelMktData(i)
            time.sleep(1)

    def start(self, symbols, trade_qty):
        print "HFT model started."
        

#        self.trade_qty = trade_qty

        self.conn.connect()  # Get IB connection object
        self.__init_stocks_data(symbols)
        self.__request_streaming_data(self.conn)

        print "Bootstrapping the model..."
        start_time = time.time()
#        self.__request_historical_data(self.conn)
#        self.__wait_for_download_completion()
#        self.strategy_params.set_bootstrap_completed()
#        self.__print_elapsed_time(start_time)

        print "Calculating strategy parameters..."
        start_time = time.time()
#        self.__calculate_strategy_params()
#        self.__print_elapsed_time(start_time)

        print "Trading started."
        try:
#            self.__update_charts()
                time.sleep(1)
        
                

        except Exception, e:
            print "Exception:", e
            print "Cancelling...",
            self.__cancel_market_data_request()

            print "Disconnecting..."
            self.conn.disconnect()
            time.sleep(1)
            self.prices.to_hdf(self.store)
            self.store.close()

            print "Disconnected."
        time.sleep(15)
        self.conn.disconnect()
#        self.store.close()
